from . import interface_v2 as flash_attn_2
from . import interface_v3 as flash_attn_3

__all__ = ["flash_attn_2", "flash_attn_3"]
